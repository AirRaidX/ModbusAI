import asyncio
import os  # Import the os module to use os.path
import traceback
from datetime import datetime
from typing import Optional, Dict, Any, List, Tuple
from pymodbus.client import ModbusTcpClient as ModbusClient
from pymodbus.exceptions import ModbusException
from api.enums import LogType, WingmanInitializationErrorType
from api.interface import (
    SettingsConfig,
    SkillConfig,
    WingmanConfig,
    WingmanInitializationError,
)
from services.file import get_writable_dir
from skills.skill_base import Skill

class ModbusAI(Skill):
    DEV_MODE = False

    def __init__(
        self,
        config: SkillConfig,
        wingman_config: WingmanConfig,
        settings: SettingsConfig,
        wingman: "Wingman",
    ) -> None:
        super().__init__(
            config=config, wingman_config=wingman_config, settings=settings, wingman=wingman
        )

        self.data_path = get_writable_dir(os.path.join("skills", "modbus_communicator", "data"))
        self.logfileerror = os.path.join(self.data_path, "error.log")
        self.logfiledebug = os.path.join(self.data_path, "debug.log")
        self.cachefile = os.path.join(self.data_path, "cache.json")

        self.skill_version = "v1"
        self.skill_loaded = False
        self.skill_loaded_asked = False
        self.game_version = "unknown"

        self.modbus_host: Optional[str] = None
        self.modbus_port: Optional[int] = None

        self.client = None

        asyncio.create_task(self.load_skill())

    async def load_skill(self):
        try:
            # Simulate some skill loading process
            await asyncio.sleep(2)  # Example delay for loading
            self.skill_loaded = True
            print("ModbusCommunicator skill successfully loaded.")
        except Exception as e:
            print(f"Error loading ModbusCommunicator skill: {e}")
            with open(self.logfileerror, "a", encoding="UTF-8") as file_object:
                file_object.write(traceback.format_exc())
                file_object.write(f"Error loading skill on date: {datetime.now()}\n")
                file_object.write(f"Version: {self.skill_version}\n")

    async def validate(self) -> List[WingmanInitializationError]:
        errors = await super().validate()

        self.modbus_host = self.retrieve_custom_property_value("modbus_host", errors)
        modbus_port_str = self.retrieve_custom_property_value("modbus_port", errors)

        if modbus_port_str is None:
            errors.append(
                WingmanInitializationError(
                    wingman_name=self.name,
                    message="Modbus port is not configured.",
                    error_type=WingmanInitializationErrorType.CONFIGURATION,
                )
            )
        else:
            try:
                self.modbus_port = int(modbus_port_str)
            except ValueError:
                errors.append(
                    WingmanInitializationError(
                        wingman_name=self.name,
                        message="Modbus port is not a valid integer.",
                        error_type=WingmanInitializationErrorType.CONFIGURATION,
                    )
                )

        if not errors:
            try:
                self.client = ModbusClient(self.modbus_host, port=self.modbus_port)
                self.client.connect()
                print(f"Connected to Modbus server at {self.modbus_host}:{self.modbus_port}")
            except ModbusException as e:
                errors.append(
                    WingmanInitializationError(
                        wingman_name=self.name,
                        message=f"Failed to connect to Modbus server: {e}",
                        error_type=WingmanInitializationErrorType.UNKNOWN,
                    )
                )
                print(f"Error connecting to Modbus server: {e}")

        return errors

    async def _print(self, message: str | dict, is_extensive: bool = False, is_debug: bool = True) -> None:
        if (not is_extensive and self.settings.debug_mode) or not is_debug:
            await self.printr.print_async(
                message,
                color=LogType.INFO,
            )
        elif self.DEV_MODE:
            with open(self.logfiledebug, "a", encoding="UTF-8") as f:
                f.write(f"#### Time: {datetime.now()} ####\n")
                f.write(f"{message}\n\n")

    def _log(self, message: str | dict, is_extensive: bool = False) -> None:
        if not is_extensive and self.settings.debug_mode:
            self.printr.print(
                message,
                color=LogType.INFO,
                server_only=True,
            )
        elif self.DEV_MODE:
            with open(self.logfiledebug, "a", encoding="UTF-8") as f:
                f.write(f"#### Time: {datetime.now()} ####\n")
                f.write(f"{message}\n\n")

    async def execute_tool(
        self, tool_name: str, parameters: Dict[str, Any]
    ) -> Tuple[str, str]:
        function_response = ""
        instant_response = ""

        functions = {
            "read_coils": "read_coils",
            "write_coil": "write_coil",
            "read_input_registers": "read_input_registers",
            "write_register": "write_register",
            "read_holding_registers": "read_holding_registers",
        }

        try:
            if tool_name in functions:
                if not self.skill_loaded:
                    self.skill_loaded_asked = True
                    await self._print("ModbusCommunicator skill is not loaded yet. Please wait a moment.", False, False)
                    function_response = "Data is still being loaded. Please wait a moment."
                    return function_response, instant_response

                self.start_execution_benchmark()
                await self._print(f"Executing function: {tool_name}")
                function = getattr(self, "_gpt_call_" + functions[tool_name])
                function_response = await function(**parameters)
                if self.settings.debug_mode:
                    await self.print_execution_time()
                if self.DEV_MODE:
                    await self._print(f"_gpt_call_{functions[tool_name]} response: {function_response}", True)
        except Exception:
            with open(self.logfileerror, "a", encoding="UTF-8") as file_object:
                file_object.write(traceback.format_exc())
                file_object.write(
                    "========================================================================================\n"
                )
                file_object.write(
                    f"Above error while executing custom function: _gpt_call_{tool_name}\n"
                )
                file_object.write(f"With parameters: {parameters}\n")
                file_object.write(f"On date: {datetime.now()}\n")
                file_object.write(f"Version: {self.skill_version}\n")
                file_object.write(
                    "========================================================================================\n"
                )
            await self._print(
                f"Error while executing custom function: {tool_name}\nCheck log file for more details."
            )
            function_response = f"Error while executing custom function: {tool_name}"
            function_response += "\nTell user there seems to be an error. And you must say that it should be reported to the 'ModbusCommunicator skill developer'."

        return function_response, instant_response

    async def _gpt_call_read_coils(self, address: int, count: int) -> str:
        try:
            result = self.client.read_coils(address, count)
            return str(result.bits)
        except ModbusException as e:
            return f"Error reading coils: {e}"

    async def _gpt_call_write_coil(self, address: int, value: bool) -> str:
        try:
            self.client.write_coil(address, value)
            return f"Written {value} to coil at address {address}"
        except ModbusException as e:
            return f"Error writing coil: {e}"

    async def _gpt_call_read_input_registers(self, address: int, count: int) -> str:
        try:
            result = self.client.read_input_registers(address, count)
            return str(result.registers)
        except ModbusException as e:
            return f"Error reading input registers: {e}"

    async def _gpt_call_write_register(self, address: int, value: int) -> str:
        try:
            self.client.write_register(address, value)
            return f"Written {value} to register at address {address}"
        except ModbusException as e:
            return f"Error writing register: {e}"

    async def _gpt_call_read_holding_registers(self, address: int, count: int) -> str:
        try:
            result = self.client.read_holding_registers(address, count)
            return str(result.registers)
        except ModbusException as e:
            return f"Error reading holding registers: {e}"

    def get_tools(self) -> List[Tuple[str, Dict]]:
        tools = [
            (
                "read_coils",
                {
                    "type": "function",
                    "function": {
                        "name": "read_coils",
                        "description": "Reads the value of a number of coils.",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "address": {"type": "integer", "description": "The starting address to read from."},
                                "count": {"type": "integer", "description": "The number of coils to read."},
                            },
                            "required": ["address", "count"],
                        },
                    },
                },
            ),
            (
                "write_coil",
                {
                    "type": "function",
                    "function": {
                        "name": "write_coil",
                        "description": "Writes a value to a single coil.",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "address": {"type": "integer", "description": "The address of the coil to write to."},
                                "value": {"type": "boolean", "description": "The value to write to the coil (true for ON, false for OFF)."},
                            },
                            "required": ["address", "value"],
                        },
                    },
                },
            ),
            (
                "read_input_registers",
                {
                    "type": "function",
                    "function": {
                        "name": "read_input_registers",
                        "description": "Reads the value of a number of input registers.",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "address": {"type": "integer", "description": "The starting address to read from."},
                                "count": {"type": "integer", "description": "The number of input registers to read."},
                            },
                            "required": ["address", "count"],
                        },
                    },
                },
            ),
            (
                "write_register",
                {
                    "type": "function",
                    "function": {
                        "name": "write_register",
                        "description": "Writes a value to a single holding register.",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "address": {"type": "integer", "description": "The address of the register to write to."},
                                "value": {"type": "integer", "description": "The value to write to the register."},
                            },
                            "required": ["address", "value"],
                        },
                    },
                },
            ),
            (
                "read_holding_registers",
                {
                    "type": "function",
                    "function": {
                        "name": "read_holding_registers",
                        "description": "Reads the value of a number of holding registers.",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "address": {"type": "integer", "description": "The starting address to read from."},
                                "count": {"type": "integer", "description": "The number of holding registers to read."},
                            },
                            "required": ["address", "count"],
                        },
                    },
                },
            ),
        ]

        return tools

    async def is_waiting_response_needed(self, tool_name: str) -> bool:
        return True

    async def update_configuration(self, new_config: Dict[str, Any]) -> None:
        """
        Dynamically updates the Modbus configuration.
        """
        self.modbus_host = new_config.get("modbus_host", self.modbus_host)
        modbus_port_str = new_config.get("modbus_port", self.modbus_port)

        if modbus_port_str is not None:
            try:
                self.modbus_port = int(modbus_port_str)
            except ValueError:
                print("Modbus port is not a valid integer. Configuration update aborted.")
                return

        # Reinitialize the client with new configuration
        if self.client:
            self.client.close()
        self.client = ModbusClient(self.modbus_host, port=self.modbus_port)
        try:
            self.client.connect()
            print(f"Reconnected to Modbus server at {self.modbus_host}:{self.modbus_port}")
        except ModbusException as e:
            print(f"Failed to reconnect to Modbus server: {e}")

    def get_configuration(self) -> Dict[str, Any]:
        """
        Returns the current Modbus configuration.
        """
        return {
            "modbus_host": self.modbus_host,
            "modbus_port": self.modbus_port,
        }
