"""Message."""
__all__ = [
    "Message",
    "MessageType",
]

from pymodbus.message.message import Message, MessageType
